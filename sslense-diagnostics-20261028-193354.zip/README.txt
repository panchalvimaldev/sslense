SSLense diagnostic bundle, version 0.9.0, created 2026-10-28 14:03 UTC.

Contents: system summary, health check results, configuration, managed certificates,
IIS sites and bindings, interrupted operations, service heartbeat, and the newest log files.

Never included: private keys, ACME account keys, PFX files, SMTP passwords, webhook URLs,
and DPAPI-protected values. Email addresses are masked, and URL paths and query strings are
removed except for Let's Encrypt and HTTP-01 challenge URLs.

Site and host names were replaced with placeholders such as site-1 and host-1.example.
Certificate thumbprints are included; they are public identifiers, not secrets.

Review the files before sharing them.
